package services;

import Domain.Result;
import Domain.User;
import Domain.questions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserServices {
    DatabaseConnection db= new DatabaseConnection();

    //for login

    public User getUser(String username, String password) {
        User user = null;
        String query = "select * from user where username=? and password=?";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            pstm.setString(1, username);
            pstm.setString(2, password);

            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                user = new User();
                user.setId(rs.getString("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    //for signup

    public void setUser(String username, String password, String role) {
        User user = null;
        String query = "insert into user(username,password,role) values(?,?,?)";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            pstm.setString(1, username);
            pstm.setString(2, password);
            pstm.setString(3, role);
            pstm.execute();
            System.out.println("Insert success!!");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * method to add questions
     */
    public void addQuestion(String subject, String questions, String option1, String option2, String option3, String option4, String correctans) {

        String query = "insert into questions(subject,questions,option1,option2,option3,option4,correctans) values(?,?,?,?,?,?,?)";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            pstm.setString(1, subject);
            pstm.setString(2, questions);
            pstm.setString(3, option1);
            pstm.setString(4, option2);
            pstm.setString(5, option3);
            pstm.setString(6, option4);
            pstm.setString(7, correctans);
            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * method to get list of questions by subject
     */
    public List<questions> getQuestionsListBySubject(String subject) {
        List<questions> questionsList = new ArrayList<questions>();
        questions question = null;
        String query="select * from questions where subject=? limit 1";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {

            pstm.setString(1, subject);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                question = new questions();
                question.setId(rs.getInt("id"));
                question.setSubject(rs.getString("subject"));
                question.setQuestions(rs.getString("questions"));
                question.setOption1(rs.getString("option1"));
                question.setOption2(rs.getString("option2"));
                question.setOption3(rs.getString("option3"));
                question.setOption4(rs.getString("option4"));
                question.setCorrectans(rs.getString("correctans"));

                questionsList.add(question);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return questionsList;
    }


    public List<questions> getNextQuestionsListBySubject(String subject,int id) {
        List<questions> questionsList = new ArrayList<questions>();
        questions question = null;
        String query="select * from questions where subject=? and id>? limit 1";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {

            pstm.setString(1, subject);
            pstm.setInt(2,id);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                question = new questions();
                question.setId(rs.getInt("id"));
                question.setSubject(rs.getString("subject"));
                question.setQuestions(rs.getString("questions"));
                question.setOption1(rs.getString("option1"));
                question.setOption2(rs.getString("option2"));
                question.setOption3(rs.getString("option3"));
                question.setOption4(rs.getString("option4"));
                question.setCorrectans(rs.getString("correctans"));

                questionsList.add(question);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return questionsList;
    }



    //to insert user's ans in useranswertable
    public void adduseranswer(String username, String questions, String userans, String correctanswer, String result) {

        String query = "insert into useranswertable(username,questions,userans,correctanswer,result) values(?,?,?,?,?)";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            pstm.setString(1, username);
            pstm.setString(2, questions);
            pstm.setString(3, userans);
            pstm.setString(4, correctanswer);
            if (userans.equalsIgnoreCase(correctanswer))
            {
                pstm.setString(5,"correct");
            }
            else
            {
                pstm.setString(5, "wrong");
            }
            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * method to get list of all questions
     */
    public List<questions> getQuestionsList() {
        List<questions> questionsList = new ArrayList<questions>();
        questions question = null;
        String query="select * from questions";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                question = new questions();
                question.setId(rs.getInt("id"));
                question.setSubject(rs.getString("subject"));
                question.setQuestions(rs.getString("questions"));
                question.setOption1(rs.getString("option1"));
                question.setOption2(rs.getString("option2"));
                question.setOption3(rs.getString("option3"));
                question.setOption4(rs.getString("option4"));
                question.setCorrectans(rs.getString("correctans"));

                questionsList.add(question);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return questionsList;
    }

    //edit

    public questions geteditQuestions(String id) {
        questions questions = null;
        String query = "select * from questions where id=?";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            pstm.setString(1,id);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                questions = new questions();
                questions.setId(rs.getInt("id"));
                questions.setSubject(rs.getString("subject"));
                questions.setQuestions(rs.getString("questions"));
                questions.setOption1(rs.getString("option1"));
                questions.setOption2(rs.getString("option2"));
                questions.setOption3(rs.getString("option3"));
                questions.setOption4(rs.getString("option4"));
                questions.setCorrectans(rs.getString("correctans"));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    /**
     * method to update questions
     */
    public void updateQuestions( String subject, String questions,String option1,String option2,String option3, String option4,String correctans,int id) {
        questions question = null;
        String query = "update questions set subject=?,questions=?,option1=?,option2=?,option3=?,option4=?,correctans=? where id=?";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            pstm.setString(1,subject);
            pstm.setString(2,questions);
            pstm.setString(3,option1);
            pstm.setString(4,option2);
            pstm.setString(5,option3);
            pstm.setString(6,option4);
            pstm.setString(7,correctans);
            pstm.setInt(8,id);
            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    //to get question and correctanswer

    public questions getQC(int id) {
        String query="select * from questions where id=?";
        questions question=null;
        PreparedStatement pstm1 = db.getPreparedStatement(query);
        try {
            pstm1.setInt(1,id);
            ResultSet rs = pstm1.executeQuery();
            while (rs.next()) {
                question = new questions();
                question.setQuestions(rs.getString("questions"));
                question.setCorrectans(rs.getString("correctans"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return question;
    }
}
