package services;

import Domain.Result;
import Domain.questions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QuestionServices {

    DatabaseConnection db = new DatabaseConnection();
    //to display resultlist

    public List<Result> getResultList() {
        Result result = null;
        List<Result> resultList = new ArrayList<Result>();
        String query = "select * from useranswertable";
        PreparedStatement pstm = db.getPreparedStatement(query);
        try {
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                result = new Result();
                result.setId(rs.getInt("id"));
                result.setUsername(rs.getString("username"));
                result.setQuestions(rs.getString("questions"));
                result.setUserans(rs.getString("userans"));
                result.setCorrectanswer(rs.getString("correctanswer"));
                result.setResult(rs.getString("result"));
                resultList.add(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultList;
    }

    }
