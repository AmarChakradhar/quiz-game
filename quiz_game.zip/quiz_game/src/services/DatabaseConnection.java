package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseConnection {
    private final String url="jdbc:mysql://localhost:3306/quiz";
    private final String username="root";
    private final String password="";
    Connection connection=null;

    public DatabaseConnection() {
        try {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection Success!!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public PreparedStatement getPreparedStatement(String query) {
        PreparedStatement pstm = null;
        try {
            pstm = connection.prepareStatement(query);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return pstm;
    }
}