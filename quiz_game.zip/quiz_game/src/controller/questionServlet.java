package controller;

import Domain.Result;
import Domain.questions;
import services.QuestionServices;
import services.UserServices;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "questionServlet")
public class questionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String pRequest=request.getParameter("pRequest");

    //to view result
        if (pRequest.equalsIgnoreCase("result"))
        {
            List<Result> resultList= new QuestionServices().getResultList();
            request.setAttribute("resultlist",resultList);
            System.out.println(resultList);
            RequestDispatcher rd= request.getRequestDispatcher("user/result.jsp");
            rd.forward(request,response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request,response);
    }
}
