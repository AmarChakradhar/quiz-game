package controller;

import Domain.User;
import sun.net.httpserver.HttpServerImpl;

import javax.print.attribute.standard.MediaSize;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "userFilter")
public class userFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest request= (HttpServletRequest) req;
        HttpServletResponse  response= (HttpServletResponse) resp;
        HttpSession session= request.getSession();

        String pRequest= request.getParameter("pRequest");
        User user= (User) session.getAttribute("user");
        if(pRequest==null)
        {
            pRequest= "NA";
        }

        if (pRequest.equalsIgnoreCase("NA"))
        {
            if(user==null) {
                request.setAttribute("msg", "Please login");
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);

            }
            else
            {
                RequestDispatcher rd=request.getRequestDispatcher("user/home.jsp");
                rd.forward(request,response);
            }
        }
        if (!pRequest.equalsIgnoreCase("login") && !pRequest.equalsIgnoreCase("logout") && !pRequest.equalsIgnoreCase("newone"))
        {
            if (user==null)
            {
                request.setAttribute("msg", "Please login");
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);
            }
        }

        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
