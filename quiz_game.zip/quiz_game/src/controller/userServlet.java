package controller;

import Domain.User;
import Domain.questions;
import services.QuestionServices;
import services.UserServices;

import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;


public class userServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    String pRequest= request.getParameter("pRequest");



    //for login
    if (pRequest.equalsIgnoreCase("login"))
    {
        UserServices us=new UserServices();
        String username=request.getParameter("username");
        String password=request.getParameter("password");

        User user=us.getUser(username,password);
        if (user!=null)
        {
            request.setAttribute("msg", "login successful");
            HttpSession session = request.getSession(false);
            session.setAttribute("user",user);
            RequestDispatcher rd= request.getRequestDispatcher("user/home.jsp");
            rd.forward(request,response);
        }
        else {
            request.setAttribute("msg", "invalid email or password");
            RequestDispatcher rd= request.getRequestDispatcher("index.jsp");
            rd.forward(request,response);
        }
    }
        // to take to signup page
        if (pRequest.equalsIgnoreCase("newone")) {
            RequestDispatcher rd = request.getRequestDispatcher("signup.jsp");
            rd.forward(request, response);
        }
        // for signup
        if (pRequest.equalsIgnoreCase("signup")) {
            UserServices us = new UserServices();
            String username1 = request.getParameter("signupusername");
            String password1 = request.getParameter("signuppassword");
            String role1 = request.getParameter("signuprole");
            us.setUser(username1, password1, role1);
            request.setAttribute("msg", "Sign Up Success!!");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }
//for logout
        if (pRequest.equalsIgnoreCase("logout")) {
            HttpSession session = request.getSession(false);
            session.invalidate();
            request.setAttribute("msg","Logout Success!!");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request,response);

        }
        //to send to page home
        if (pRequest.equalsIgnoreCase("home"))
        {
            RequestDispatcher rd=request.getRequestDispatcher("user/home.jsp");
            rd.forward(request,response);
        }
        //to send to page playquiz
        if (pRequest.equalsIgnoreCase("playquiz"))
        {
        RequestDispatcher rd=request.getRequestDispatcher("user/playquiz.jsp");
        rd.forward(request,response);
        }



        //to send to page editquestion
        if (pRequest.equalsIgnoreCase("editquestion"))
        {
            RequestDispatcher rd=request.getRequestDispatcher("admin/editquestion.jsp");
            rd.forward(request,response);
        }

        /**
         * to add questions
         */
        if (pRequest.equalsIgnoreCase("addQuestion")) {
            UserServices us=new UserServices();
            String subject = request.getParameter("subject");
            String questions =request.getParameter("questions");
            String option1 = request.getParameter("option1");
            String option2 = request.getParameter("option2");
            String option3 = request.getParameter("option3");
            String option4 = request.getParameter("option4");
            String correctans = request.getParameter("correctans");

            us.addQuestion(subject,questions,option1,option2,option3,option4,correctans);
            request.setAttribute("msg","Question Added");
            RequestDispatcher rd= request.getRequestDispatcher("admin/editquestion.jsp");
            rd.forward(request,response);
        }

        /**
         * For selecting question by subject
         */
        if (pRequest.equalsIgnoreCase("play")) {
            int id=Integer.parseInt(request.getParameter("id"));
            String subject=request.getParameter("subjectoption");
            List<questions> questionList = new UserServices().getQuestionsListBySubject(subject);
            request.setAttribute("questionList",questionList);
            request.setAttribute("subject",subject);
            RequestDispatcher rd=request.getRequestDispatcher("user/questionfile.jsp");
            rd.forward(request,response);

        }



        //to add to useranswertable
        if (pRequest.equalsIgnoreCase("gameplay")) {
            String subject = request.getParameter("subject");
            int id= Integer.parseInt(request.getParameter("id"));
            UserServices us=new UserServices();

            HttpSession session = request.getSession(false);
            User user=(User)session.getAttribute("user");

            String userans = request.getParameter("userans");
            String questions =request.getParameter("tquestions");
            String correctanswer = request.getParameter("tcorrectans");
            String result=request.getParameter("result");
            us.adduseranswer(user.getUsername(),questions,userans,correctanswer,result);
            List<questions> questionList = new UserServices().getNextQuestionsListBySubject(subject,id);
            request.setAttribute("questionList",questionList);

            request.setAttribute("msg","Ans Added");
            RequestDispatcher rd= request.getRequestDispatcher("user/questionfile.jsp");
            rd.forward(request,response);
        }

        /**
         * For selecting all question
         */
        if (pRequest.equalsIgnoreCase("questionlists")) {
            List<questions> questionList = new UserServices().getQuestionsList();
            request.setAttribute("questionLists",questionList);
            System.out.println("vayo");
            RequestDispatcher rd=request.getRequestDispatcher("user/questionslists.jsp");
            rd.forward(request,response);
        }

        //send to page update question
        if(pRequest.equalsIgnoreCase("updatequestion"))
        {
            RequestDispatcher rd=request.getRequestDispatcher("user/updatequestion.jsp");
            rd.forward(request,response);
        }

        //to go to updateq
        if (pRequest.equalsIgnoreCase("update")) {
            String id = request.getParameter("id");
            questions questions = new UserServices().geteditQuestions(id);
            request.setAttribute("questions",questions);
            RequestDispatcher rd = request.getRequestDispatcher("user/updateq.jsp");
            rd.forward(request,response);
        }

        //update questions
        if (pRequest.equalsIgnoreCase("editquestions")) {

            String subject = request.getParameter("updatesubject");
            String questions = request.getParameter("updatequestions");
            String option1 = request.getParameter("updateoption1");
            String option2 = request.getParameter("updateoption2");
            String option3 = request.getParameter("updateoption3");
            String option4 = request.getParameter("updateoption4");
            String correctans = request.getParameter("updatecorrectans");
            int id= Integer.parseInt(request.getParameter("id"));
            UserServices us = new UserServices();
            us.updateQuestions(subject,questions,option1,option2,option3,option4,correctans,id);
            request.setAttribute("msg", "Edited Successfully!!");
            List<questions> questionsList = new UserServices().getQuestionsList();
            request.setAttribute("QuestionLists", questionsList);
            RequestDispatcher rd = request.getRequestDispatcher("user/questionslists.jsp");
            rd.forward(request, response);
        }



    }




    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
doPost(request,response);
    }


    private void redirectLogin(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session.getAttribute("user") == null) {
            request.setAttribute("msg", "Session Expired");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }
    }

    protected void getQuestionList(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
//        redirectLogin(request,response);
        List<questions> questionList = new UserServices().getQuestionsList();
        request.setAttribute("questionList",questionList);
        RequestDispatcher rd = request.getRequestDispatcher("user/questionslists.jsp");
        rd.forward(request,response);
    }
}
