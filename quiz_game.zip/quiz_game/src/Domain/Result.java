package Domain;

public class Result {
    int id;
    String username;
    String questions;
    String userans;
    String result;
    String correctanswer;
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getQuestions() {
        return questions;
    }

    public void setQuestions(String questions) {
        this.questions = questions;
    }

    public String getUserans() {
        return userans;
    }

    public void setUserans(String userans) {
        this.userans = userans;
    }

    public String getCorrectanswer() {
        return correctanswer;
    }

    public void setCorrectanswer(String correctanswer) {
        this.correctanswer = correctanswer;
    }


}
